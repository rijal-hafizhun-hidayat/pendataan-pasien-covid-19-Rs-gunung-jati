<?php 
	include "konek.php";
	
 ?>